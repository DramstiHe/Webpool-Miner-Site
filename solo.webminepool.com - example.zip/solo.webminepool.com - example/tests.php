<?php
  include_once("handler.php");
  $app->hashrate_withdraw($_COOKIE['btc_address']);
?>